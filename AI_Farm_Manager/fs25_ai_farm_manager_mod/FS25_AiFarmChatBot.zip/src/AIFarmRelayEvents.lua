--[[
  AIFarmRelayEvents.lua — FS25 Event classes for !bot relay over multiplayer (no public backendUrl).

  Pattern matches GIANTS Event + InitEventClass (see FS25_BulkFill OpenCoverEvent).
  Server broadcasts AIFarmBotRequestEvent; relay PC responds with AIFarmBotResponseEvent.

  IMPORTANT: Do not gate readStream/writeStream with connection:getIsServer() — on dedicated MP the
  Connection object can disagree with the real sender/receiver, so guarded reads skip bytes and
  trigger packetReceived errors on the client. Always serialize the same fields; gate only in run().
--]]

-- Use engine helpers (same as FS25_UniversalAutoload etc.) — manual Int32+bytes breaks packetReceived.
local function _writeStr(streamId, str)
    streamWriteString(streamId, tostring(str or ""))
end

local function _readStr(streamId)
    local s = streamReadString(streamId)
    if s == nil then
        return ""
    end
    return s
end

-- ——— Server → all clients: carry !bot line to the relay PC ———

AIFarmBotRequestEvent = {}
local AIFarmBotRequestEvent_mt = Class(AIFarmBotRequestEvent, Event)
InitEventClass(AIFarmBotRequestEvent, "AIFarmBotRequestEvent")

function AIFarmBotRequestEvent.emptyNew()
    local self = Event.new(AIFarmBotRequestEvent_mt)
    return self
end

function AIFarmBotRequestEvent.new(playerName, message, requestId, serverToken)
    local self = AIFarmBotRequestEvent.emptyNew()
    self.playerName = playerName or ""
    self.message = message or ""
    self.requestId = requestId or 0
    self.serverToken = serverToken or ""
    return self
end

function AIFarmBotRequestEvent:readStream(streamId, connection)
    self.playerName = _readStr(streamId)
    self.message = _readStr(streamId)
    self.requestId = streamReadInt32(streamId)
    self.serverToken = _readStr(streamId)
    self:run(connection)
end

function AIFarmBotRequestEvent:writeStream(streamId, connection)
    _writeStr(streamId, self.playerName)
    _writeStr(streamId, self.message)
    streamWriteInt32(streamId, self.requestId)
    _writeStr(streamId, self.serverToken)
end

function AIFarmBotRequestEvent:run(connection)
    -- Do not use connection:getIsServer() here — GDN examples use it for re-broadcast patterns, but on
    -- dedicated MP clients it can be wrong and skip the handler entirely (no log, no API).
    -- Headless server has no g_client; any machine with a local game client does.
    if g_client == nil then
        return
    end
    Logging.info("[AIFarmManager] Relay: client received bot request id=%s", tostring(self.requestId))
    if AIFarmRelayClient ~= nil and AIFarmRelayClient.handleBotRequest ~= nil then
        AIFarmRelayClient.handleBotRequest(self)
    end
end

-- ——— Client → server: return LLM reply ———

AIFarmBotResponseEvent = {}
local AIFarmBotResponseEvent_mt = Class(AIFarmBotResponseEvent, Event)
InitEventClass(AIFarmBotResponseEvent, "AIFarmBotResponseEvent")

function AIFarmBotResponseEvent.emptyNew()
    local self = Event.new(AIFarmBotResponseEvent_mt)
    return self
end

function AIFarmBotResponseEvent.new(requestId, replyText, ok)
    local self = AIFarmBotResponseEvent.emptyNew()
    self.requestId = requestId or 0
    self.replyText = replyText or ""
    self.ok = ok and true or false
    return self
end

function AIFarmBotResponseEvent:readStream(streamId, connection)
    self.requestId = streamReadInt32(streamId)
    self.ok = streamReadBool(streamId)
    self.replyText = _readStr(streamId)
    self:run(connection)
end

function AIFarmBotResponseEvent:writeStream(streamId, connection)
    streamWriteInt32(streamId, self.requestId)
    streamWriteBool(streamId, self.ok)
    _writeStr(streamId, self.replyText)
end

function AIFarmBotResponseEvent:run(connection)
    if self.requestId == nil then
        return
    end
    if g_server == nil then
        return
    end
    local ok, isSrv = pcall(function()
        return g_server:getIsServer()
    end)
    if not ok or not isSrv then
        return
    end
    if AIFarmRelayServer ~= nil and AIFarmRelayServer.onBotResponse ~= nil then
        AIFarmRelayServer.onBotResponse(self)
    end
end
