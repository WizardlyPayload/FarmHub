-- FS25 FarmDashboard | RedTapeDataCollector.lua | v1.0.0
-- Optional FS25_RedTape export — policies, schemes, tax, grants, event log (aggregate + capped lists).

RedTapeDataCollector = {}

local MAX_EVENTS = 20
local MAX_TAX_STATEMENTS = 12
local MAX_POLICIES = 16
local MAX_SCHEMES = 12
local MAX_GRANTS = 8
local TIER_NAMES = { [1] = "A", [2] = "B", [3] = "C", [4] = "D" }

local function rtEnabled()
    local rt = _G.g_currentMission and _G.g_currentMission.RedTape
    return rt ~= nil
end

local function rtTierLabel(tierNum)
    return TIER_NAMES[tonumber(tierNum)] or "D"
end

local function rtPolicyNameKey(policy)
    if not policy then return nil end
    if policy.getName then
        local ok, name = pcall(function() return policy:getName() end)
        if ok and name then return tostring(name) end
    end
    local idx = tonumber(policy.policyIndex)
    if idx and _G.RTPolicies and _G.RTPolicies[idx] then
        return _G.RTPolicies[idx].name
    end
    return nil
end

local function rtSchemeNameKey(scheme)
    if not scheme then return nil end
    if scheme.getName then
        local ok, name = pcall(function() return scheme:getName() end)
        if ok and name then return tostring(name) end
    end
    local idx = tonumber(scheme.schemeIndex)
    if idx and _G.RTSchemes and _G.RTSchemes[idx] then
        return _G.RTSchemes[idx].name
    end
    return nil
end

local function rtWarningCountForFarm(policySystem, farmId, policyIndex)
    if not policySystem or not policySystem.warnings then return 0 end
    local n = 0
    for _, w in pairs(policySystem.warnings) do
        if w and w.farmId == farmId and w.policyIndex == policyIndex then
            n = n + (tonumber(w.warningCount) or 1)
        end
    end
    return n
end

local function rtSerializePolicies(rt, farmId)
    local ps = rt.PolicySystem
    if not ps or not ps.policies then return {} end
    local out = {}
    for _, policy in ipairs(ps.policies) do
        if policy and #out < MAX_POLICIES then
            local watching = false
            if policy.isBeingWatchedByFarm then
                local ok, w = pcall(function() return policy:isBeingWatchedByFarm(farmId) end)
                watching = ok and w == true
            elseif policy.watchingFarms and policy.watchingFarms[farmId] then
                watching = true
            end
            table.insert(out, {
                policyIndex = tonumber(policy.policyIndex),
                nameKey = rtPolicyNameKey(policy),
                warnings = rtWarningCountForFarm(ps, farmId, policy.policyIndex),
                watched = watching,
                nextEvaluationMonth = tonumber(policy.nextEvaluationMonth),
                evaluationCount = tonumber(policy.evaluationCount) or 0,
            })
        end
    end
    return out
end

local function rtSerializeSchemes(schemeSystem, farmId, active)
    if not schemeSystem then return {} end
    local list = active
        and (schemeSystem.getActiveSchemesForFarm and schemeSystem:getActiveSchemesForFarm(farmId))
        or (schemeSystem.getAvailableSchemesForCurrentFarm and schemeSystem:getAvailableSchemesForCurrentFarm())
    if type(list) ~= "table" then return {} end
    local out = {}
    for _, scheme in pairs(list) do
        if scheme and #out < MAX_SCHEMES then
            if not active or tonumber(scheme.farmId) == farmId or tonumber(scheme.farmId) == -1 then
                table.insert(out, {
                    schemeIndex = tonumber(scheme.schemeIndex),
                    nameKey = rtSchemeNameKey(scheme),
                    tier = rtTierLabel(scheme.tier),
                    watched = scheme.watched == true,
                    farmId = tonumber(scheme.farmId),
                })
            end
        end
    end
    return out
end

local function rtSerializeGrants(grantSystem, farmId)
    if not grantSystem or not grantSystem.getGrantsForFarm then return {} end
    local ok, grants = pcall(function() return grantSystem:getGrantsForFarm(farmId) end)
    if not ok or type(grants) ~= "table" then return {} end
    local out = {}
    for _, grant in pairs(grants) do
        if grant and #out < MAX_GRANTS then
            table.insert(out, {
                grantId = grant.grantId and tostring(grant.grantId) or nil,
                status = grant.status and tostring(grant.status) or nil,
                approvedAmount = tonumber(grant.approvedAmount),
                requestedAmount = tonumber(grant.requestedAmount),
                xmlFilename = grant.xmlFilename and tostring(grant.xmlFilename) or nil,
            })
        end
    end
    return out
end

local function rtSerializeTax(taxSystem, farmId)
    if not taxSystem then
        return { statements = {}, currentMonthIncome = 0, currentMonthExpenses = 0 }
    end
    local statements = {}
    if taxSystem.taxStatements then
        for _, stmt in ipairs(taxSystem.taxStatements) do
            if stmt and tonumber(stmt.farmId) == farmId and #statements < MAX_TAX_STATEMENTS then
                table.insert(statements, {
                    month = tonumber(stmt.month),
                    totalTax = tonumber(stmt.totalTax) or 0,
                    totalTaxableIncome = tonumber(stmt.totalTaxableIncome) or 0,
                    totalExpenses = tonumber(stmt.totalExpenses) or 0,
                    paid = stmt.paid == true,
                    taxRate = tonumber(stmt.taxRate),
                })
            end
        end
    end
    table.sort(statements, function(a, b) return (a.month or 0) > (b.month or 0) end)

    local income, expenses = 0, 0
    if taxSystem.lineItems and taxSystem.lineItems[farmId] then
        local cumMonth = _G.RedTape and _G.RedTape.getCumulativeMonth and _G.RedTape.getCumulativeMonth() or nil
        if cumMonth and taxSystem.lineItems[farmId][cumMonth] then
            for _, line in ipairs(taxSystem.lineItems[farmId][cumMonth]) do
                if line then
                    income = income + (tonumber(line.income) or 0)
                    expenses = expenses + (tonumber(line.expense) or 0)
                end
            end
        end
    end

    return {
        statements = statements,
        currentMonthIncome = income,
        currentMonthExpenses = expenses,
    }
end

local function rtSerializeEvents(eventLog, farmId)
    if not eventLog or not eventLog.events then return {} end
    local out = {}
    for i = #eventLog.events, 1, -1 do
        local ev = eventLog.events[i]
        if ev and tonumber(ev.farmId) == farmId and #out < MAX_EVENTS then
            local typeKey = nil
            if _G.RTEventLogItem and _G.RTEventLogItem.EVENT_TYPE_LABELS then
                typeKey = _G.RTEventLogItem.EVENT_TYPE_LABELS[ev.eventType]
            end
            table.insert(out, 1, {
                eventType = tonumber(ev.eventType),
                typeKey = typeKey,
                detail = ev.detail and tostring(ev.detail) or "",
                month = tonumber(ev.month),
                year = tonumber(ev.year),
            })
        end
    end
    return out
end

local function rtSerializeFarm(rt, farmId)
    local ps = rt.PolicySystem
    local points = 0
    local tierNum = 4
    if ps then
        if ps.points and ps.points[farmId] then
            points = tonumber(ps.points[farmId]) or 0
        end
        if ps.getTierForPoints then
            local ok, t = pcall(function() return ps:getTierForPoints(points) end)
            if ok and t then tierNum = t end
        end
    end

    local tax = rtSerializeTax(rt.TaxSystem, farmId)
    return {
        farmId = farmId,
        tier = rtTierLabel(tierNum),
        tierNum = tierNum,
        points = points,
        policies = rtSerializePolicies(rt, farmId),
        activeSchemes = rtSerializeSchemes(rt.SchemeSystem, farmId, true),
        availableSchemes = rtSerializeSchemes(rt.SchemeSystem, farmId, false),
        grants = rtSerializeGrants(rt.GrantSystem, farmId),
        tax = tax,
        events = rtSerializeEvents(rt.EventLog, farmId),
    }
end

function RedTapeDataCollector:init()
    RedTapeDataCollector._inc = false
end

function RedTapeDataCollector:collectBegin()
    RedTapeDataCollector._inc = true
end

function RedTapeDataCollector:collectStep()
    if RedTapeDataCollector._inc then
        RedTapeDataCollector._inc = false
        return true, self:collect()
    end
    return true, { enabled = false }
end

function RedTapeDataCollector:collect()
    if not rtEnabled() then
        return { enabled = false }
    end

    local rt = _G.g_currentMission.RedTape
    local byFarm = {}
    if _G.g_farmManager and _G.g_farmManager.farms then
        for _, farm in pairs(_G.g_farmManager.farms) do
            local fid = farm and tonumber(farm.farmId)
            if fid and fid > 0 then
                local hasPlayers = false
                if farm.players then
                    for _ in pairs(farm.players) do hasPlayers = true break end
                end
                local name = farm.name and tostring(farm.name):match("^%s*(.-)%s*$") or ""
                if hasPlayers or name ~= "" then
                    local ok, row = pcall(function() return rtSerializeFarm(rt, fid) end)
                    if ok and row then byFarm[tostring(fid)] = row end
                end
            end
        end
    end

    if next(byFarm) == nil then
        local mission = _G.g_currentMission
        if mission and mission.getFarmId then
            local ok, fid = pcall(function() return mission:getFarmId() end)
            if ok and fid and fid > 0 then
                local ok2, row = pcall(function() return rtSerializeFarm(rt, fid) end)
                if ok2 and row then byFarm[tostring(fid)] = row end
            end
        end
    end

    return { enabled = true, byFarm = byFarm }
end
