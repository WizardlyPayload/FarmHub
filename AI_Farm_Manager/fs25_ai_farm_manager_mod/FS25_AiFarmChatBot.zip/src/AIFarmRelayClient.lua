--[[
  AIFarmRelayClient.lua — runs on the relay PC (relayAccept=true): POST /api/chat/complete on localhost.

  Important: do not call io.popen / HTTP from inside Event:run() for packetReceived — FS25 often
  blocks io there (curl_popen_failed). We queue requests from the event and drain the queue from
  AIFarmBridge:update() instead.
--]]

AIFarmRelayClient = {}
AIFarmRelayClient._queue = {}
AIFarmRelayClient._inFlight = false

local function _decodeJson(str)
    if str == nil then
        return nil
    end
    if json ~= nil and json.decode ~= nil then
        local ok, data = pcall(function()
            return json.decode(str)
        end)
        if ok then
            return data
        end
    end
    return nil
end

--- Called from network event (packetReceived). Only queues — no I/O here.
function AIFarmRelayClient.handleBotRequest(ev)
    if ev == nil then
        return
    end
    local cfg = AIFarmBridge.config
    if cfg == nil or not cfg.relayAccept then
        Logging.warning(
            "[AIFarmManager] Relay: bot request id=%s ignored — set relayAccept=true in ai_farm_manager_config.xml on this PC.",
            tostring(ev.requestId)
        )
        return
    end
    table.insert(AIFarmRelayClient._queue, {
        requestId = ev.requestId,
        playerName = ev.playerName,
        message = ev.message,
        serverToken = ev.serverToken,
    })
end

--- Run one queued relay POST (from mission update — io.popen allowed). Call each frame from main.lua.
function AIFarmRelayClient.processQueue()
    if AIFarmRelayClient._inFlight then
        return
    end
    local q = AIFarmRelayClient._queue
    if q == nil or #q == 0 then
        return
    end
    local item = table.remove(q, 1)
    local cfg = AIFarmBridge.config
    if cfg == nil then
        return
    end
    local base = cfg.localBackendUrl or "http://127.0.0.1:8765"
    base = string.gsub(base, "/+$", "")
    local url = base .. "/api/chat/complete"
    local body = string.format(
        '{"player":%q,"message":%q,"server_token":%q}',
        tostring(item.playerName),
        tostring(item.message),
        tostring(item.serverToken)
    )

    AIFarmRelayClient._inFlight = true
    AIFarmHttp.postJson(url, body, function(status, respBody, err)
        AIFarmRelayClient._inFlight = false
        local reply = ""
        local ok = false
        if status == 200 and respBody ~= nil then
            local data = _decodeJson(respBody)
            if data ~= nil and data.reply ~= nil then
                reply = tostring(data.reply)
                ok = true
            end
        end
        if not ok then
            local hint = ""
            local e = tostring(err)
            if e == "curl_popen_failed" or e == "curl_tmp_open_failed" then
                hint = " curl/io failed (ensure curl.exe works from a normal shell; relay runs from update() now)."
            elseif e == "curl_parse_failed" then
                hint = " curl returned unexpected output (often CRLF/HTTP parse; retry or update mod)."
            end
            Logging.warning(
                "[AIFarmManager] Relay client: /api/chat/complete failed status=%s err=%s%s (is FastAPI on %s?)",
                tostring(status),
                e,
                hint,
                tostring(base)
            )
        end
        local resp = AIFarmBotResponseEvent.new(item.requestId, reply, ok)
        if g_client ~= nil and g_client.getServerConnection ~= nil then
            local okc, conn = pcall(function()
                return g_client:getServerConnection()
            end)
            if okc and conn ~= nil and conn.sendEvent ~= nil then
                conn:sendEvent(resp)
            end
        end
    end)
end
