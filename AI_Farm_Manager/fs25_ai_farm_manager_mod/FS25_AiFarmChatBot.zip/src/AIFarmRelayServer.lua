--[[
  AIFarmRelayServer.lua — dedicated / host: broadcast bot request to all clients over the game connection.
--]]

AIFarmRelayServer = {}

function AIFarmRelayServer.sendBotRequest(playerName, message)
    if g_server == nil then
        return
    end
    local cfg = AIFarmBridge.config
    if cfg == nil or cfg.serverToken == nil or cfg.serverToken == "" then
        return
    end
    local rid = math.random(1, 2147483646)
    local ev = AIFarmBotRequestEvent.new(playerName, message, rid, cfg.serverToken)
    -- Match ChatEvent / engine examples: single-arg fan-out. The (event, nil, nil, object) form is for
    -- entity-bound events (e.g. BulkFill passes the vehicle); nil object can skip client delivery.
    g_server:broadcastEvent(ev)
    Logging.info("[AIFarmManager] Relay: broadcast bot request id=%s", tostring(rid))
end

function AIFarmRelayServer.onBotResponse(self)
    if self == nil then
        return
    end
    local text = self.replyText or ""
    if not self.ok or text == "" then
        text = "Sorry — no reply from AI Farm Manager on this PC. Start the API (see README) or check relayAccept/localBackendUrl."
    end
    local line = "[Bot] " .. tostring(text)
    if AIFarmChatHooks ~= nil and AIFarmChatHooks.broadcastBot ~= nil then
        AIFarmChatHooks.broadcastBot(line, AIFarmBridge.BOT_SENDER)
    end
end
